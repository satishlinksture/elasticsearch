<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Developer\MissingSkus\Cron;

use Psr\Log\LoggerInterface;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Mirasvit\SearchElastic\SearchAdapter\Manager;

class Cron
{
    protected $logger;

    protected $manager;

    protected $fileSystem;

    protected $directoryList;

    protected $productCollectionFactory;

    /**
     * Constructor
     *
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(
        LoggerInterface $logger,
        Manager $manager,
        Filesystem $fileSystem,
        DirectoryList $directoryList,
        CollectionFactory $productCollectionFactory
    ) {
        $this->logger = $logger;
        $this->manager = $manager;
        $this->fileSystem = $fileSystem;
        $this->directoryList = $directoryList;
        $this->productCollectionFactory = $productCollectionFactory;
    }

    /**
     * Execute the cron
     *
     * @return void
     */
    public function execute()
    {
        try {
            $directory = $this->fileSystem->getDirectoryWrite(DirectoryList::VAR_DIR);
            $contents = $productCollection->getSelect();
            $directory->writeFile("missing-skus.txt", $contents);

            $elasticSearchStatus = $this->manager->status();
            if ($elasticSearchStatus) {
                $directory->writeFile("missing-skus.txt", 'Elastic Search is running.');
            } else {
            }

            $productCollection = $this->productCollectionFactory->create();
            $productCollection->addAttributeToFilter('visibility', 4);
            $productCollection->addAttributeToFilter('status', 1);
            $productCollection->setOrder('entity_id', 'DESC');
            foreach ($productCollection as $product) {
                
            }            
        } catch (\Exception $e) {

        }
    }
}

